package in.ashokit.service;

import java.util.List;

import in.ashokit.entities.UserAccount;

public interface UserAccountService {
	
	public String saveOrUpdateUserAcc(UserAccount userAcc);
	
	public List<UserAccount> getAllUserAcccounts();
	
	public UserAccount getUserAcc (Integer UserID);
	
	public boolean deleteUserAcc (Integer userID);
	
	public boolean updateAccStatus (Integer userId, String status);
	

}
