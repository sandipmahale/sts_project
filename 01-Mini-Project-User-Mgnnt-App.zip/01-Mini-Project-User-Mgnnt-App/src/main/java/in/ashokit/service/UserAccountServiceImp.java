package in.ashokit.service;


import java.util.List;
import java.util.Optional;

import org.apache.catalina.authenticator.SpnegoAuthenticator.AcceptAction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ashokit.entities.UserAccount;
import in.ashokit.repository.UserAccountRepo;

@Service
public class UserAccountServiceImp implements UserAccountService {
	
	
	
	@Autowired
	private UserAccountRepo userAccountRepo;

	

	@Override
	public String saveOrUpdateUserAcc(UserAccount userAcc) {
		
		
	Integer userId = userAcc.getUserid();
	
		userAccountRepo.save(userAcc);
		
		if(userId == null)
		{
			return "User Record Saved";
		}
		else {
			{
				return "User Record Updated";
			}
		}
	}

	@Override
	public List<UserAccount> getAllUserAcccounts() {
		
		List<UserAccount> accounts=userAccountRepo.findAll();
		
		return null;
	}

	@Override
	public UserAccount getUserAcc(Integer userID) {
		
		Optional<UserAccount> findByidOptional=userAccountRepo.findById(userID);
		if(findByidOptional.isPresent()) {
			return findByidOptional.get();
			
		}
		
		return null;
	}

	@Override
	public boolean deleteUserAcc(Integer userID) {
		
		boolean exitsById = userAccountRepo.existsById(userID);
		if (exitsById)
		{
			userAccountRepo.deleteById(userID);
			return true;
		}
		
		return false;
	}

	@Override
	public boolean updateAccStatus(Integer userId, String status) {

             try {
            	 
            	 //userAccountRepo.updateUserAccStatus(userId,status);
            	 return true;
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		return false;
	}

}
