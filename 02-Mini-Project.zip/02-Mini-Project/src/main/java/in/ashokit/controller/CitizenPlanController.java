package in.ashokit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import ch.qos.logback.core.model.Model;
import in.ashokit.binding.SearchCriteria;
import in.ashokit.service.CitizenPlanService;

@Controller
public class CitizenPlanController {

	@Autowired
	private CitizenPlanService service;
	
	@GetMapping("/")
	public String index(Model model) {
		List<String> planNames =service.getPlanName();
		List<String> planStatus =service.getStatus();
		
		 model.addAttribute("plan-names-list", planNames);
		model.addAttribute("plan-status-list",planStatus);
		
		model.addAttribute("search",new SearchCriteria());
		
		return "index";
	}
	
}
