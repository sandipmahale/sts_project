package in.ashokit.runner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.formula.functions.Now;
import org.hibernate.Incubating;
import org.hibernate.annotations.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import in.ashokit.entity.CitizenPlan;
import in.ashokit.repo.CitizenPlanRepo;


@Component 
public class DataLoader implements ApplicationRunner {
	
	@Autowired
   private CitizenPlanRepo repo;


	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		
		CitizenPlan p1= new CitizenPlan("Jonh", "jonh@Incubating.com",1234 , 98765 ,"Male", "Cash" , "Approved", LocalDate.now() , LocalDate.now().plusMonths(6));
		CitizenPlan p2= new CitizenPlan("Vikranth", "vikranth@Incubating.com",2334 , 98265 ,"Fmale", "food" , "Denied",null,null);
		CitizenPlan p3= new CitizenPlan("Ram", "ram@Incubating.com",3452 , 987645 ,"Male", "Cash" , "Approved",null,null);
		CitizenPlan p4= new CitizenPlan("Sam", "sam@Incubating.com",34433 , 987265 ,"Male", "Cash" , "Denied",null,null);
		CitizenPlan p5= new CitizenPlan("Vir", "vir@Incubating.com",3244 , 987465 ,"fmale", "Famle" , "Approved",null,null);
		CitizenPlan p6= new CitizenPlan("Jay", "jay@Incubating.com",3234 , 987665 ,"Male", "Cash" , "Denied",null,null);
		
		List<CitizenPlan> records=Arrays.asList(p1,p2,p3,p4,p5,p6);
		
		repo.saveAll(records);
          
	}
}
