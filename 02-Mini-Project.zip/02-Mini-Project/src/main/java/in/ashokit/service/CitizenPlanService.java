package in.ashokit.service;

import java.util.List;

import in.ashokit.binding.SearchCriteria;
import in.ashokit.entity.CitizenPlan;
import jakarta.servlet.http.HttpServletResponse;

public interface CitizenPlanService {
	
	public List<String> getPlanName( );
	
	public List<String> getStatus();
	
	public List<CitizenPlan> serchcitizensCitizens(SearchCriteria criteria);
	
	public void generateExcel(HttpServletResponse response);
	
	
	public void generatepdf (HttpServletResponse response);

}
