package in.ashokit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ashokit.binding.SearchCriteria;
import in.ashokit.entity.CitizenPlan;
import in.ashokit.repo.CitizenPlanRepo;
import jakarta.servlet.http.HttpServletResponse;

import in.ashokit.binding.SearchCriteria;
import in.ashokit.entity.CitizenPlan;


@Service
public class CitizenPlanServiceImpl implements CitizenPlanService {
	
	
	@Autowired
	private CitizenPlanRepo repo;

	@Override
	public List<String> getPlanName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public void generateExcel(HttpServletResponse response) {
		// TODO Auto-generated method stub

	}

	@Override
	public void generatepdf(HttpServletResponse response) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<CitizenPlan> serchcitizensCitizens(SearchCriteria criteria) {
		// TODO Auto-generated method stub
		return null;
	}

}
